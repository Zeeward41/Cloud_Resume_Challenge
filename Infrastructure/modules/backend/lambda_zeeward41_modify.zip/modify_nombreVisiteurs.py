import boto3

dynamo_client = boto3.client('dynamodb')


table = 'Table_zeeward41'
site_id = 'site_zeeward41'
# Obtenir le nombre de visiteurs atuels

def lambda_handler(event, context):
    responseGet = dynamo_client.get_item(
        TableName = table,
        Key= {
            'siteID': { 'S': site_id
            }
        },
        ProjectionExpression='NombreVisiteurs'
        )
    
    valeur = int(responseGet["Item"]["NombreVisiteurs"]["N"]) + 1
    
    
    
    
    response_update = dynamo_client.update_item(
        TableName = table,
        Key= {
            'siteID': { 'S': site_id}
        },
        UpdateExpression='SET NombreVisiteurs = :nv',
        ExpressionAttributeValues={
            ':nv' : {'N': str(valeur)}
        }
        )
    
    return {
        "statusCode": "200",
        "headers": {
            "Access-Control-Allow-Origin": "*",
        },
        "n_visiteurs": valeur,
        
    }