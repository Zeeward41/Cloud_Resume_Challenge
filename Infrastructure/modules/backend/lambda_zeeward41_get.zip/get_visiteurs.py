import boto3
import json

dynamo_client = boto3.client('dynamodb')


table = 'Table_zeeward41'
site_id = 'site_zeeward41'
# Obtenir le nombre de visiteurs atuels

def lambda_handler(event, context):

    
    responseGet = dynamo_client.get_item(
        TableName = table,
        Key= {
            'siteID': { 'S': site_id
            }
        },
        ProjectionExpression='NombreVisiteurs'
        )
    visiteur_count =  responseGet["Item"]["NombreVisiteurs"]["N"]
    #visiteur_count = 2
    
    response = {
        "statusCode": "200",
        "headers": {
            "Access-Control-Allow-Origin": "*",
        },
        "n_visiteurs": visiteur_count,
        
    }

    return response
    